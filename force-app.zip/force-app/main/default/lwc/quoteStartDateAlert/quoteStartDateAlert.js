import { LightningElement, api, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';

const FIELDS = ['SBQQ__Quote__c.SBQQ__StartDate__c'];

export default class QuoteStartDateAlert extends LightningElement {

    @api recordId;
    showAlert = false;

    @wire(getRecord, { recordId: '$recordId', fields: FIELDS })
    wiredQuote({ data }) {
        if (data) {
            const startDate = data.fields.SBQQ__StartDate__c?.value;
            if (startDate) {
                const today = new Date();
                today.setHours(0, 0, 0, 0);

                const quoteStart = new Date(startDate);
                this.showAlert = quoteStart < today;
            }
        }
    }

    handleClose() {
        this.showAlert = false;
    }
}